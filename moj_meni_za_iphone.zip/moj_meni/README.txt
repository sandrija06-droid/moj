MOJ MENI — jednostavna aplikacija za iPhone

KAKO DA POKRENEŠ:
1. Raspakuj ZIP fajl na računaru.
2. Otvori index.html u internet pregledaču da probaš aplikaciju.
3. Za korišćenje na iPhone-u, fajl mora da bude postavljen na HTTPS hosting (npr. GitHub Pages ili Netlify), pa otvori dobijenu adresu u Safariju.
4. U Safariju pritisni Share (kvadrat sa strelicom) > Add to Home Screen / Dodaj na početni ekran.

FUNKCIJE:
- 8 početnih stolova, možeš dodavati i brisati stolove.
- Dodavanje pića sa nazivom, cenom i opcionom kategorijom.
- Pretraga pića.
- Dodavanje pića u porudžbinu stola i menjanje količine.
- Čuvanje u localStorage pregledača na istom uređaju.

NAPOMENA:
Ovo je lokalni prototip. Podaci se čuvaju u pregledaču na uređaju, ne sinhronizuju se automatski između telefona i računara. Ne briši podatke sajta/pregledača ako želiš da sačuvaš meni i porudžbine.
